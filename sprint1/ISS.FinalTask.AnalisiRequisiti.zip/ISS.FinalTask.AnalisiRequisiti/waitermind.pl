%====================================================================================
% waitermind description   
%====================================================================================
context(ctxwaiter, "localhost",  "TCP", "8090").
 qactor( waiterbody, ctxwaiter, "external").
  qactor( waitermind, ctxwaiter, "it.unibo.waitermind.Waitermind").
