%====================================================================================
% barman description   
%====================================================================================
context(ctxbarman, "localhost",  "TCP", "8060").
 qactor( barman, ctxbarman, "it.unibo.barman.Barman").
