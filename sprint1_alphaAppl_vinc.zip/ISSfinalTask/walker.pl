%====================================================================================
% walker description   
%====================================================================================
mqttBroker("localhost", "1883", "unibo/polar").
context(ctxwalker, "127.0.0.1",  "TCP", "8070").
context(ctxtearoom_dummy, "localhost",  "TCP", "8030").
 qactor( waiterwalker, ctxtearoom_dummy, "external").
  qactor( walker, ctxwalker, "it.unibo.walker.Walker").
