%====================================================================================
% client description   
%====================================================================================
mqttBroker("localhost", "1883", "unibo/polar").
context(ctxclient, "localhost",  "TCP", "8040").
context(ctxsmartbell, "127.0.0.1",  "TCP", "8050").
 qactor( smartbell, ctxsmartbell, "external").
  qactor( client, ctxclient, "it.unibo.client.Client").
