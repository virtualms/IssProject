%====================================================================================
% smartbell description   
%====================================================================================
mqttBroker("localhost", "1883", "unibo/polar").
context(ctxsmartbell, "localhost",  "TCP", "8050").
 qactor( smartbell, ctxsmartbell, "it.unibo.smartbell.Smartbell").
  qactor( client, ctxsmartbell, "it.unibo.client.Client").
