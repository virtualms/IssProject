%====================================================================================
% waiterwalker description   
%====================================================================================
mqttBroker("localhost", "1883", "unibo/polar").
context(ctxtearoom_dummy, "localhost",  "TCP", "8030").
context(ctxbasicrobot, "127.0.0.1",  "TCP", "8020").
 qactor( basicrobot, ctxbasicrobot, "external").
  qactor( waiterwalker, ctxtearoom_dummy, "it.unibo.waiterwalker.Waiterwalker").
