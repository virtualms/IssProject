package consolegui

val mqtthostAddr    = "broker.hivemq.com"
val mqttport		= "1883" 
val hostAddr 		= "localhost" //"192.168.1.5" "localhost"
val port     		= "8020"
val qakdestination 	= "basicrobot"
val ctxqadest       = "ctxbasicrobot"