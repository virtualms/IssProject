%====================================================================================
% waiter description   
%====================================================================================
mqttBroker("localhost", "1883", "unibo/polar").
context(ctxwaiter, "localhost",  "TCP", "8090").
context(ctxwalker, "127.0.0.1",  "TCP", "8070").
 qactor( walker, ctxwalker, "external").
  qactor( waiter, ctxwaiter, "it.unibo.waiter.Waiter").
