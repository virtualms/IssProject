package consolegui

val mqtthostAddr    = "localhost"
val mqttport		= "1883" 
val hostAddr 		= "localhost" //"192.168.1.5" "localhost"
val port     		= "8090"
val qakdestinationTable = "waiterbody"
val qakdestinationBell = "smartbell"
val ctxqadest       = "ctxwaiter"