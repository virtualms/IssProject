package connQak

object sysConnKb{
	
	val mqtthostAddr    = "broker.hivemq.com"
	val mqttport		= "1883" 
	val hostAddr 		= "192.168.1.22"
	val port     		= "8014"
	val qakdestination 	= "virtualrobot"
	val ctxqadest       = "ctxvirtualdemo"
	
	
	//val qakdestination 	= "nanorobot"
	//val ctxqadest       = "ctxnanodemo"
	
	//val qakdestination 	= "mbotrobot"
	//val ctxqadest       = "ctxmbotdemo"

}