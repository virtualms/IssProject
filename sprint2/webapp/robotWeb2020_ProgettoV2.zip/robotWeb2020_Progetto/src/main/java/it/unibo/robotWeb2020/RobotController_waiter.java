package it.unibo.robotWeb2020;

import connQak.Configuratore;
import connQak.configurator;
import connQak.connQakCoap;
import it.unibo.kactor.ApplMessage;
import it.unibo.kactor.MsgUtil;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


@Controller 
public class RobotController_waiter {
    String appName     ="robotGui";
    String viewModelRep="startup";
    String robotHost = ""; //ConnConfig.hostAddr;
    String robotPort = ""; //ConnConfig.port;

    //String htmlPage  = "robotGuiPost";
    String htmlPage  = "robotGuiSocket";
    //String htmlPage  = "robotGuiPostBoundary";

    Set<String> robotMoves = new HashSet<String>();

    connQakCoap connQakSupport;
    connQakCoap connQakSupportSmartBell;

	Configuratore conf ;

    public RobotController_waiter() {
    	conf = new Configuratore("waiter");

        htmlPage  = conf.pageTemplate;
        robotHost =	conf.hostAddr;
        robotPort = conf.port;

        robotMoves.addAll(Arrays.asList("enterYes","enterNo", "wantOrder1","wantOrder2","order1","order2","wantPay1","wantPay2","pay"));

        connQakSupport = new connQakCoap(  );
        connQakSupport.createConnection("waiter");

		connQakSupportSmartBell = new connQakCoap(  );
		connQakSupportSmartBell.createConnection("smartBell");
     }

	//FOR FORM REQUESTS
	@PostMapping( path = "/move" )
	public String doMove(
			@RequestParam(name="move", required=false, defaultValue="enter")
					String moveName, Model viewmodel) {
		//necessario?
    	preparePageUpdating();

		System.out.println("------------------- RobotController doMove move=" + moveName  );
		if( robotMoves.contains(moveName) ) {
			doBusinessJob(moveName, viewmodel);
		}else {
			viewmodel.addAttribute("arg", "Sorry: move unknown - Current Robot State:"+viewModelRep );
		}
		return htmlPage;
	}

	//FOR socket
	@MessageMapping("/move")
	public void doMoveSocket(
			@RequestBody Map<String, String> payload) {
    	String moveName = payload.get("name");//.get("name").toString();
		System.out.println("------------------- RobotController doMove move=" + moveName  );
		if( robotMoves.contains(moveName) ) {
			doBusinessJob(moveName, null);
		}
	}
	
	/*
	 * INTERACTION WITH THE BUSINESS LOGIC			
	 */
	protected void doBusinessJob( String moveName, Model viewmodel) {
		try {
			String destName = conf.qakdest;
			ApplMessage msg = null;
			switch (moveName) {
				case "enterYes" : {
					msg = MsgUtil.buildRequest("web", "enter", "enter(37)", "smartbell");
					connQakSupportSmartBell.request(msg);
				}; break;
				case "enterNo" : {
					msg = MsgUtil.buildRequest("web", "enter", "enter(38)", "smartbell");
					connQakSupportSmartBell.request(msg);
				}; break;
				case "wantOrder1" : {
					msg = MsgUtil.buildRequest("web","readyToOrder","readyToOrder(1)", destName);
					connQakSupport.request(msg);
				}; break;
				case "wantOrder2" : {
					msg = MsgUtil.buildRequest("web","readyToOrder","readyToOrder(2)", destName);
					connQakSupport.request(msg);
				}; break;
				case "order1" : {
					msg = MsgUtil.buildDispatch("web","order","order(3, 1)", destName );
					connQakSupport.forward(msg);
				}; break;
				case "order2" : {
					msg = MsgUtil.buildDispatch("web","order","order(3, 2)", destName );
					connQakSupport.forward(msg);
				}; break;
				case "wantPay1" : {
					msg = MsgUtil.buildRequest("console","readyToPay","readyToPay(1)", destName );
					connQakSupport.request(msg);
				}; break;
				case "wantPay2" : {
					msg = MsgUtil.buildRequest("console","readyToPay","readyToPay(2)", destName );
					connQakSupport.request(msg);
				}; break;
				case "pay" : {
					msg = MsgUtil.buildDispatch("console","moneyCollected","moneyCollected(5)", destName );
					connQakSupport.forward(msg);
				}; break;
			}

			//WAIT for command completion ...
//			Thread.sleep(400);  //QUITE A LONG TIME ...
			if( viewmodel != null ) {
				ResourceRep rep = getWebPageRep();
				viewmodel.addAttribute("arg", "Current Robot State:  "+rep.getContent());
			}
		} catch (Exception e) {
			System.out.println("------------------- RobotController doBusinessJob ERROR=" + e.getMessage()  );
			e.printStackTrace();
		}		
	}

    @ExceptionHandler 
    public ResponseEntity<String> handle(Exception ex) {
    	HttpHeaders responseHeaders = new HttpHeaders();
        return new ResponseEntity<String>(
        		"RobotController ERROR " + ex.getMessage(), responseHeaders, HttpStatus.CREATED);
    }

	public ResourceRep getWebPageRep()   {
		String resourceRep = connQakSupport.readRep();
		System.out.println("------------------- RobotController_waiter resourceRep=" + resourceRep  );
		return new ResourceRep("" + HtmlUtils.htmlEscape(resourceRep)  );
	}

	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;

	public void preparePageUpdating() {

		connQakSupport.getClient().observe(new CoapHandler() {
			@Override
			public void onLoad(CoapResponse response) {

				System.out.println("RobotController_waiter	--> waiter changed ->" + response);

				simpMessagingTemplate.convertAndSend(WebSocketConfig.topicForWaiter,
						new ResourceRep("" + HtmlUtils.htmlEscape(response.getResponseText())));
			}
			@Override
			public void onError() {
				System.out.println("RobotController_waiter --> CoapClient error!");
			}
		});
	}

	@MessageMapping("/update/waiter")
	@SendTo("/topic/display/waiter")
	public ResourceRep update(@Payload String message) {
		ResourceRep rep = getWebPageRep();
		return rep;
	}
}

