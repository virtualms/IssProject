package it.unibo.robotWeb2020;

import connQak.Configuratore;
import connQak.connQakCoap;
import it.unibo.kactor.ApplMessage;
import it.unibo.kactor.MsgUtil;
import org.eclipse.californium.core.CoapHandler;
import org.eclipse.californium.core.CoapResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.HtmlUtils;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;


@Controller 
public class RobotController_barman {
    String robotHost = ""; //ConnConfig.hostAddr;
    String robotPort = ""; //ConnConfig.port;

    String htmlPage  = "robotGuiSocket";

    connQakCoap connQakSupport_barman;

	Configuratore conf ;

    public RobotController_barman() {
    	conf = new Configuratore("barman");

        htmlPage  = conf.pageTemplate;
        robotHost =	conf.hostAddr;
        robotPort = conf.port;

        connQakSupport_barman = new connQakCoap(  );
        connQakSupport_barman.createConnection("barman");

     }

    @ExceptionHandler 
    public ResponseEntity<String> handle(Exception ex) {
    	HttpHeaders responseHeaders = new HttpHeaders();
        return new ResponseEntity<String>(
        		"RobotController ERROR " + ex.getMessage(), responseHeaders, HttpStatus.CREATED);
    }

	public ResourceRep getWebPageRep()   {
		String resourceRep = connQakSupport_barman.readRep();
		System.out.println("------------------- RobotController_barmanUploader resourceRep=" + resourceRep  );
		return new ResourceRep("" + HtmlUtils.htmlEscape(resourceRep)  );
	}

	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;

	public void preparePageUpdating() {

		connQakSupport_barman.getClient().observe(new CoapHandler() {
			@Override
			public void onLoad(CoapResponse response) {

				System.out.println("RobotController_barman --> barman changed ->" + response);

				simpMessagingTemplate.convertAndSend(WebSocketConfig.topicForBarman,
						new ResourceRep("" + HtmlUtils.htmlEscape(response.getResponseText())));
			}
			@Override
			public void onError() {
				System.out.println("RobotController_barman --> CoapClient error!");
			}
		});
	}

	@MessageMapping("/update/barman")
	@SendTo("/topic/display/barman")
	public ResourceRep update(@Payload String message) {
		ResourceRep rep = getWebPageRep();
		return rep;
	}
}

