package connQak;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.PathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.util.Properties;

public class Configuratore {

    private static final String RESOURCE_FILE = "contexts.properties";

    public String pageTemplate;
    public String hostAddr;
    public String port;
    public String qakdest;
    public String ctxqadest;
    public String stepsize;

    public Configuratore(String dest) {

        try {
            Properties prop = PropertiesLoaderUtils.loadProperties(new PathResource("./" + RESOURCE_FILE));
            pageTemplate = prop.getProperty(dest + ".pageTemplate");
            hostAddr = prop.getProperty(dest + ".hostAddr");
            port = prop.getProperty(dest + ".port");
            qakdest = prop.getProperty(dest + ".qakdest");
            ctxqadest = prop.getProperty(dest + ".ctxqadest");
            stepsize = prop.getProperty(dest + ".stepsize");
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
