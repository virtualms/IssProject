package consolegui
 
object consoleGuiMqttBell{
	fun create(  hostIP : String,     port : String,     destName : String) {
		consoleGuiSimpleBell( connQak.ConnectionType.MQTT, hostIP, port, destName)
	}
}
 
fun main(){
	
	consoleGuiMqttBell.create( mqtthostAddr, mqttport, qakdestinationBell)
}
 