package consolegui

object consoleGuiTcpBell{
	fun create(  hostIP : String,     port : String,     destName : String) {
		consoleGuiSimpleBell( connQak.ConnectionType.TCP, hostIP, port, destName)
	}
}
fun main(){
	consoleGuiTcpBell.create( hostAddr, port, qakdestinationBell)
}
 