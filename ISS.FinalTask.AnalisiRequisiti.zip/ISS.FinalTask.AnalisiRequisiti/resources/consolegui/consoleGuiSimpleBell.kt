package consolegui

import connQak.connQakBase
import it.unibo.`is`.interfaces.IObserver
import java.util.Observable
import connQak.ConnectionType
import it.unibo.kactor.MsgUtil

class consoleGuiSimpleBell( val connType : ConnectionType, val hostIP : String,   val port : String,
						val destName : String ) : IObserver {
lateinit var connQakSupport : connQakBase
	
  		 val buttonLabels = arrayOf("Suono Campanello")
 
	
	init{
		create( connType )
	}
		 fun create( connType : ConnectionType){
			 connQakSupport = connQakBase.create(connType, hostIP, port,destName )
			 connQakSupport.createConnection()
			 var guiName = ""
			 when( connType ){
				 ConnectionType.COAP -> guiName="GUI-COAP"
				 ConnectionType.MQTT -> guiName="GUI-MQTT"
				 ConnectionType.TCP  -> guiName="GUI-TCP"
 				 ConnectionType.HTTP -> guiName="GUI-HTTP"
			 }
			 createTheGui( guiName )		 
		  }
		  fun createTheGui( guiName : String ){
	  			val concreteButton = ButtonAsGui.createButtons( guiName, buttonLabels )
	            concreteButton.addObserver( this )		  
		  }
	 
	
	  
	  override fun update(o: Observable, arg: Any) {	   
    	   var move = arg as String
		  if( move.equals("Suono Campanello", true) ){
			  //val msg = MsgUtil.buildRequest("console", "waitTime", "waitTime(1)", "waitermind" )
			  
			  val msg = MsgUtil.buildRequest("console", "enter", "enter(1)", destName )
			  
			  connQakSupport.request( msg )
		  }
       }//update
	
}


fun main(){
	consoleGuiSimpleBell( ConnectionType.COAP, hostAddr, port, qakdestinationBell)
}